package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.IProductDao;
import com.capgemini.dao.ProductDaoImpl;
import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

@Transactional
@Service("productService")
public class ProductServiceImpl implements IProductService{

	@Autowired
	private IProductDao productDao;
	
	public ProductServiceImpl() {
		super();
	}

	public ProductServiceImpl(IProductDao productDao) {
		super();
		this.productDao = productDao;
	}

	public IProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(IProductDao productDao) {
		this.productDao = productDao;
	}

	@Override
	public int addProduct(Product product) throws ProductException {
		
		return productDao.addProduct(product);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		
		productDao.updateProduct(product);
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		return productDao.getProduct(id);
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		
		productDao.removeProduct(id);
		
	}


	@Override
	public List<Product> getAllProducts() throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getAllProducts();
	}


	@Override
	public Product getProductByName(String name) throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getProductByName(name);
	}


	@Override
	public List<Product> getProductsByRange(float min, float max)
			throws ProductException {
		// TODO Auto-generated method stub
		return productDao.getProductsByRange(min, max);
	}

}
