mainApp.directive("mydirective", function(){
	
	return { template : "<i>Angular Js Sample App</i>"};
});