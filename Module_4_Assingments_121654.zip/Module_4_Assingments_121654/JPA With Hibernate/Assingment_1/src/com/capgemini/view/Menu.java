package com.capgemini.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class Menu 
{
	
	
	ApplicationContext ac = new ClassPathXmlApplicationContext("spring.xml");
	 IProductService productservice = (ProductServiceImpl) ac.getBean("productService");
	
	
	Scanner sc=new Scanner(System.in);

	
	public static void main(String[] args) {
	Menu application=new Menu();
	while(true)
	{
		try
		{
			application.menu();
	
		}
		catch(Exception e)
		{
		System.out.println("Something went wrong. reason:"+e.getMessage());
		}
		}
	}
	public void menu() {
		
		
		System.out.println("1)Add Product");
		System.out.println("2)Get Product By Id");
		System.out.println("3)Update Product");
		System.out.println("4)Remove Product");
		System.out.println("5)View All Products");
		System.out.println("6)Get Product By Name");
		System.out.println("7)Get Product In Range");
		System.out.println("8)Exit Application");
		
		int choice=sc.nextInt();
		
		switch(choice)
		{
		case 1:
			addProduct();
			break;
		case 2:
			getProduct();
			break;
		case 3:
			updateProduct();
			break;
		case 4:
			removeProduct();
			break;
		case 5:
			getList();
			break;
			
		case 6:
			
			getProductByName();
			break;
			
		case 7:
			
			getProductByRange();
			break;
			
		case 8:
			System.out.println("ThankYou for using our application.");
			System.exit(0);
			break;
		
		
		}
		
		
	}

	
	public void getProductByRange()
	{
		
		System.out.println("Enter Minimum Price Range");
		float min = sc.nextFloat();
		
		System.out.println("Enter Maximum Price Range");
		float max = sc.nextFloat();
	
		
		try
		{
		List<Product> products = productservice.getProductByRange(min, max);
		
		Iterator<Product> it = products.iterator();
		System.out.printf("%s %6s %12s %s \n", "ID", "Name", "Quantity", "Price");
		
		while(it.hasNext())
		{
			
			Product product = it.next();
			
			System.out.printf("%d %6s %9d %f \n",product.getId(),product.getName(),product.getQuantity(),product.getPrice());
		}
		
		
		}
		
	
		catch(Exception e)
		{
			throw new ProductException("Product Not Found In The Range Given");
			
		}
		
		
	}

	public void getProductByName() 
	{
		System.out.println("Enter Product Name :");
		String name = sc.next();
		
		try
		{
			Product product = productservice.getProductByName(name);
			System.out.println("ID:"+product.getId());
			System.out.println(" Name:"+product.getName());
			System.out.println(" Quantity:"+product.getQuantity());
			System.out.println(" Price:"+product.getPrice());
		} 
		catch (ProductException e) 
		{
			
			System.out.println("Product not found. Reason:"+e.getMessage());
		
		}
		catch (Exception e) 
		{
			System.out.println(e.getMessage());

		}
		
	}

	public void getProduct() {
		
		System.out.println("Enter Product Id:");
		int id=sc.nextInt();
		
		try {
			Product product=productservice.getProduct(id);
			System.out.println("ID:"+product.getId());
			System.out.println(" Name:"+product.getName());
			System.out.println(" Quantity:"+product.getQuantity());
			System.out.println(" Price:"+product.getPrice());
			
			
			
		} catch (ProductException e) {
			
			System.out.println("Product not found. Reason:"+e.getMessage());
			//e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
		}
		
		
		
	}
	public void getList() 
	{
		try
		{
		List<Product> products = productservice.getAllProducts();
		
		Iterator<Product> it = products.iterator();
		
		System.out.printf("%s %6s %12s %s \n", "ID", "Name", "Quantity", "Price");
		while(it.hasNext())
		{
			Product product = it.next();
			
			System.out.printf("%d %6s %9d %f \n",product.getId(),product.getName(),product.getQuantity(),product.getPrice());
		}
		
		
		}
		
		catch (ProductException e) 
		{
			
			System.out.println("Could not add product. Reason:"+e.getMessage());
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
		}
		
	}

	public void addProduct() {
		System.out.println("Enter Product Name:");
		String pname=sc.next();
		
		System.out.println("Enter Quantity:");
		int qty=sc.nextInt();
		
		System.out.println("Enter Product Price:");
		float price=sc.nextFloat();
		
		Product p1=new Product(pname,qty,price);
		try {
			int id=productservice.addProduct(p1);
			System.out.println("Product Inserted Sucessfully");
			System.out.println("Your Product Id :"+id);
		} 
		catch (ProductException e) {
			
			System.out.println("Could not add product. Reason:"+e.getMessage());
			//e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
		}
		
	}
	
	
	public void updateProduct() {
			
		System.out.println("Enter Product Id:");
		int id=sc.nextInt();
		Product p2=	null;
		try {
			
		
			p2=	productservice.getProduct(id);
		System.out.println("Old Product Name:"+p2.getName());	
		System.out.println("Upadate? y/n");
		char reply=sc.next().toLowerCase().charAt(0);
		
		if(reply=='y')
		{
		System.out.println("Enter Product Name:");
		String pname=sc.next();
		p2.setName(pname);
		}
		
		System.out.println("Old Product Quantity:"+p2.getQuantity());	
		System.out.println("Upadate? y/n");
		reply=sc.next().toLowerCase().charAt(0);
		
		if(reply=='y')
		{
			System.out.println("Enter Quantity:");
			int qty=sc.nextInt();
		p2.setQuantity(qty);
		}
		
		System.out.println("Old Product Price:"+p2.getPrice());	
		System.out.println("Upadate? y/n");
		reply=sc.next().toLowerCase().charAt(0);
		
		if(reply=='y')
		{
			System.out.println("Enter Product Price:");
			float price=sc.nextFloat();
		p2.setPrice(price);
		}
		
		
		} 
		catch (ProductException e) {
			
			System.out.println("Product not found. Reason:"+e.getMessage());
			//e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
		}
		try{
			if(p2!=null)
			{
			productservice.updateProduct(p2);
			System.out.println("Product Updated Sucessfully");
			}
		}
			catch (ProductException e) {
			
			System.out.println("Could not update. Reason:"+e.getMessage());
			//e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
		}	
			
		}
	public void removeProduct() {
			
		System.out.println("Enter Product Id:");
		int id=sc.nextInt();
		
		try {
			productservice.removeProduct(id);
			System.out.println("product Removed Sucessfully");
			
			
			
		} catch (ProductException e) {
			
			System.out.println("Could not remove product. Reason:"+e.getMessage());
			//e.printStackTrace();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
		}
		
		}
	
	
}
