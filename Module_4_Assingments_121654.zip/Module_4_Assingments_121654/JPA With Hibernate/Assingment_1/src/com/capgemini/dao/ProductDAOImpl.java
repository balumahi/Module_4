package com.capgemini.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

@Component("productDao")
public class ProductDAOImpl implements IProductDao
{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	
	public ProductDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}


	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	public ProductDAOImpl() {
		
		System.out.println("in dao");
	}

	@Override
	public int addProduct(Product product) throws ProductException 
	{
		
		int productId = 0;
		try
		{
			productId = jdbcTemplate.queryForObject("select hibernate_sequence.nextval from dual", Integer.class);
			String sql = "insert into productDetails values(?,?,?,?)";
			
			Object[] params =  new Object[] {productId,product.getName(),product.getQuantity(),product.getPrice()};
			
			jdbcTemplate.update(sql,params);
		}
		catch (DataAccessException e) 
		{
			
			e.printStackTrace();
		}
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException 
	{
		try 
		{
			
			String sql = "update productDetails set pname=?,pquantity=?,Price=? where pid = ?";
			
			Object[] params =  new Object[] {product.getName(),product.getQuantity(),product.getPrice(),product.getId()};
			
			jdbcTemplate.update(sql,params);
		} 
		catch (DataAccessException e) 
		{
			
			e.printStackTrace();
		}
		
	}

	@Override
	public Product getProduct(int id) throws ProductException
	{
		Product product = null;
		try
		{
			String query = "select * from productDetails where pid = ?";
			
			 product = (Product) jdbcTemplate.queryForObject(query,new ProductMapper(),id);
			
		}
		catch (Exception e) 
		{
			throw new ProductException(e.getMessage());
			
		}
		
		if(product == null)
			
			throw new ProductException("No Product Found With Id"+id);
		
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException 
	{
		String sql = "delete from productdetails where pid =? ";
		
		Object[] params = new Object[]{id};
		
		jdbcTemplate.update(sql,params);
		
	}

	@Override
	public List<Product> getAllProducts() throws ProductException 
	{
		String sql = "select * from productdetails";
		
		List<Product> pList = getJdbcTemplate().query(sql, new ProductMapper());
		System.out.println("hello");
		return pList;
		
	}

	@Override
	public Product getProductByName(String name) throws ProductException 
	{
		String sql = "select * from productdetails where pname =?";
		
		Product product =  (Product) getJdbcTemplate().queryForObject(sql,new ProductMapper(),name);
		
		return product;
	}

	@Override
	public List<Product> getProductByRange(float min, float max)
			throws ProductException 
	{
		List<Product> pList;
		String sql = "select * from productdetails where price between ? and ?";
		Object[] params = new Object[]{min,max};
	
		pList =  getJdbcTemplate().query(sql,new ProductMapper(),params);
		
		return pList;
	}
}
