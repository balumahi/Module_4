package com.cg.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.beans.Employee;
import com.cg.beans.SBU;

public class MainApp 
{
	public static void main(String[] args) 
	
	{
		Resource res = new ClassPathResource("spring.xml");
		
		BeanFactory factory = new XmlBeanFactory(res);
		
		Employee emp = factory.getBean("empp",Employee.class);
		
		SBU sbu =  factory.getBean("sbu",SBU.class);
		
		System.out.println("Sbu Details");
		System.out.println("---------------------------");
		System.out.println(sbu.getSbuId()+","+sbu.getName()+","+sbu.getSbuHead());
		System.out.println("Employee Details :------------------------");
		System.out.println(sbu);

		
	}
}
