package com.capgemini.ws;

import java.util.List;

import javax.jws.WebService;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

@WebService(endpointInterface="com.capgemini.ws.IProductService")
public class ProductServiceImpl implements IProductService {

	private com.capgemini.service.IProductService productService;
	
	public ProductServiceImpl() {
		productService=new com.capgemini.service.ProductServiceImpl();
	}
	@Override
	public Product getProduct(int id) throws ProductException {
		
		return productService.getProduct(id);
	}

	@Override
	public List<Product> getAllProducts() throws ProductException 
	{
		
		return productService.getAllProducts();
	}
	/*@Override
	public int addProduct(Product product) throws ProductException {
		
		return productService.addProduct(product);
	}
	@Override
	public void updateProduct(Product product) throws ProductException {
		
		productService.updateProduct(product);
	}
	@Override
	public void removeProduct(int id) throws ProductException {
		
		productService.removeProduct(id);
	}
	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		return productService.getAllProducts();
	}
	@Override
	public Product getProductByName(String name) throws ProductException {
		
		return productService.getProductByName(name);
	}
	@Override
	public List<Product> getProductsByRange(float min, float max)
			throws ProductException {
		
		return productService.getProductsByRange(min, max);
	}*/
}
