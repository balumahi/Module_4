package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;
import com.capgemini.util.DBUtil;

public class ProductDaoImpl implements IProductDao {

	private EntityManager entityManager;
	
	public ProductDaoImpl() {
		entityManager=DBUtil.getEntityManager();
	}
	
	
	@Override
	public int addProduct(Product product) throws ProductException {
		
		int productId=0;
		try{
		
			entityManager.getTransaction().begin();
			entityManager.persist(product);
			productId=product.getId();
			entityManager.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
	
		try{
			
			entityManager.getTransaction().begin();
			entityManager.merge(product);
			entityManager.flush();
			entityManager.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		

	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		Product product=null;
	try{
			
			entityManager.getTransaction().begin();
			product=entityManager.find(Product.class,id);
			entityManager.flush();
			entityManager.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		if(product==null)
		{
			throw new ProductException("No Product found with id="+id);
		}
	
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		
		try{
			
			entityManager.getTransaction().begin();
			Product product=entityManager.find(Product.class, id);
			entityManager.remove(product);
			entityManager.getTransaction().commit();
		
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}

	}


	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		List<Product> products=null;
		try{
			
			entityManager.getTransaction().begin();
			
			TypedQuery<Product> tQuery=entityManager.createNamedQuery("GetAllProducts",Product.class);
			products=tQuery.getResultList();
			
			entityManager.getTransaction().commit();
		
			
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		if(products==null || products.isEmpty())
			throw new ProductException("No Products to display");
		return products;
	}


	@Override
	public Product getProductByName(String name) throws ProductException {
		
		Product products=null;
try{
			
			entityManager.getTransaction().begin();
			
			TypedQuery<Product> tQuery=entityManager.createQuery("select p from Product p where p.name=:pname",Product.class);
			tQuery.setParameter("pname", name);
			products=tQuery.getSingleResult();
			entityManager.getTransaction().commit();
		
			
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException(e.getMessage());
		}
		return products;
	}


	@Override
	public List<Product> getProductsByRange(float min, float max){
	List<Product> products=null;
	try{
		
		entityManager.getTransaction().begin();
		
		TypedQuery<Product> tQuery=entityManager.createQuery("select p from Product p where p.price between :pmin and :pmax",Product.class);
		tQuery.setParameter("pmin", min);
		tQuery.setParameter("pmax", max);
		products=tQuery.getResultList();
		
		entityManager.getTransaction().commit();
	
		
	}
	catch(Exception e)
	{
		entityManager.getTransaction().rollback();
		throw new ProductException(e.getMessage());
	}
	if(products==null || products.isEmpty())
		throw new ProductException("No Products to display");
	return products;
	}

}
