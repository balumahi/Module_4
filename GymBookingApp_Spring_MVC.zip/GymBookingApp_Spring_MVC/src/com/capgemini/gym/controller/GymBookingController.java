package com.capgemini.gym.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.service.IBookingService;


@Controller
public class GymBookingController
{
	@Autowired
	private IBookingService bookingService ;
	
	public GymBookingController() {
		// TODO Auto-generated constructor stub
	}

	public GymBookingController(IBookingService bookingService) {
		super();
		this.bookingService = bookingService;
	}

	public IBookingService getBookingService() {
		return bookingService;
	}

	public void setBookingService(IBookingService bookingService) {
		this.bookingService = bookingService;
	}
	
	@RequestMapping("addCustomer")
	public String getAddCustomerPage(Model model)
	{
		List<String> gymName = new ArrayList<String>();
		gymName.add("Gold Gym") ;
		gymName.add("Talwalkars") ;
		gymName.add("Cloud 9") ;
		
		List<String> timings = new ArrayList<>();
		timings.add("Morninig") ;
		timings.add("Afternoon") ;
		timings.add("Evening") ;
		timings.add("Night") ;
		
		model.addAttribute("gymName", gymName) ;
		model.addAttribute("timings", timings) ;
		model.addAttribute("customer", new Customer()) ;
		
		
		return "AddCustomerPage";
		
	}
	
	@RequestMapping(value="processAddCustomer", method=RequestMethod.POST)
	public String processAddCutomer(@ModelAttribute("customer") @Valid Customer customer ,BindingResult result, Model model)
	{
		if(result.hasErrors() == true)
		{
			List<String> gymName = new ArrayList<String>();
			gymName.add("Gold Gym") ;
			gymName.add("Talwalkars") ;
			gymName.add("Cloud 9") ;
			
			List<String> timings = new ArrayList<>();
			timings.add("Morninig") ;
			timings.add("Afternoon") ;
			timings.add("Evening") ;
			timings.add("Night") ;
			
			model.addAttribute("gymName", gymName) ;
			model.addAttribute("timings", timings) ;
			model.addAttribute("customer", customer) ;
			
			
			return "AddCustomerPage";
		}
		
		int id = -1 ;
			try
			{
				id = bookingService.addCustomer(customer);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				model.addAttribute("errMsg", "Something went wrong while adding customer reason " + e.getMessage()) ;
				return "ErrorPage" ;
			}
			
			model.addAttribute("message", "Customer added successfully with "+ id ) ;
			return "SuccessPage" ;
	}
	
	
	@RequestMapping("viewCustomer")
	public String getViewCustomerPage()
	{
		return "ViewCustomerPage" ;
	}
	
	@RequestMapping(value="processGetCustomerDetails" , method=RequestMethod.POST)
	public String processViewDetails(@RequestParam("txtId") int id , Model model)
	{
		Customer customer = null ;
		try
		{
			customer = bookingService.getCustomer(id) ;
			System.out.println(customer);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			model.addAttribute("errMsg", "Something went wrong while adding customer reason " + e.getMessage()) ;
			return "ErrorPage" ;
		}
		model.addAttribute("customer", customer) ;
		return "ViewCustomerPage" ;
	}
	
	@RequestMapping("updateCustomer")
	public String getUpdatePage(Model model)
	{
		List<String> gymName = new ArrayList<String>();
		gymName.add("Gold Gym") ;
		gymName.add("Talwalkars") ;
		gymName.add("Cloud 9") ;
		
		List<String> timings = new ArrayList<>();
		timings.add("Morninig") ;
		timings.add("Afternoon") ;
		timings.add("Evening") ;
		timings.add("Night") ;
		
		model.addAttribute("gymName", gymName) ;
		model.addAttribute("timings", timings) ;
		model.addAttribute("customer", new Customer()) ;
		
		return "UpdateCustomerPage" ;
	}
	
	@RequestMapping(name="getCustomerToUpdate",method=RequestMethod.POST)
	public String getCustToUpdate(@RequestParam("txtId") int id , Model model)
	{
		List<String> gymName = new ArrayList<String>();
		gymName.add("Gold Gym") ;
		gymName.add("Talwalkars") ;
		gymName.add("Cloud 9") ;
		
		List<String> timings = new ArrayList<>();
		timings.add("Morninig") ;
		timings.add("Afternoon") ;
		timings.add("Evening") ;
		timings.add("Night") ;
		Customer customer = null ;
		try
		{
			customer = bookingService.getCustomer(id) ;
			System.out.println(customer);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			model.addAttribute("errMsg", "Something went wrong while adding customer reason " + e.getMessage()) ;
			return "ErrorPage" ;
		}
		model.addAttribute("gymName", gymName) ;
		model.addAttribute("timings", timings) ;
		model.addAttribute("customer", customer) ;
		return "UpdateCustomerPage" ;
	}
	
	@RequestMapping("processUpdate")
	public String processUpdateCustomer(@ModelAttribute("customer") @Valid Customer customer , BindingResult result , Model model)
	{
		if(result.hasErrors() == true)
		{
			List<String> gymName = new ArrayList<String>();
			gymName.add("Gold Gym") ;
			gymName.add("Talwalkars") ;
			gymName.add("Cloud 9") ;
			
			List<String> timings = new ArrayList<>();
			timings.add("Morninig") ;
			timings.add("Afternoon") ;
			timings.add("Evening") ;
			timings.add("Night") ;
			
			model.addAttribute("gymName", gymName) ;
			model.addAttribute("timings", timings) ;
			model.addAttribute("customer", customer) ;
			
			
			return "UpdateCustomerPage";
		}
		try
		{
			bookingService.updateCustomer(customer);
		}
		catch(Exception e)
		{
			model.addAttribute("errMsg", "Could Not Update Reason " + e.getMessage()) ;
			return "ErrorPage";
		}
		model.addAttribute("message", "Update Done Successfully");
		return "SuccessPage" ;
	}
}

