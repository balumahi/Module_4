package com.capgemini.gym.service;

import com.capgemini.gym.entities.Customer;
import com.capgemini.gym.exception.BookingException;

public interface IBookingService 
{
	public int addCustomer(Customer customer) throws BookingException;
	public Customer getCustomer(int id ) throws BookingException ;
	public void updateCustomer(Customer customer) throws BookingException ;
}
