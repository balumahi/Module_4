package com.cg.dao;

import java.util.List;

import com.cg.beans.Employee;

public interface IEmployeeDAO 
{
	public List<Employee> getEmployee() ;
}
