package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.entities.Customer;
import com.capgemini.service.IBookingService;

@Controller
public class GymBookingController 
{
	@Autowired
	private IBookingService bookingService;

	public GymBookingController(IBookingService bookingService) {
		super();
		this.bookingService = bookingService;
	}

	public GymBookingController() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IBookingService getBookingService() {
		return bookingService;
	}

	public void setBookingService(IBookingService bookingService) {
		this.bookingService = bookingService;
	}
	
	@RequestMapping("addCustomer")
	public String getAddCustomerPage(Model model)
	{
		List<String>gymNames = new ArrayList<>();
		gymNames.add("Golds Gym");
		gymNames.add("Talwalkars");
		gymNames.add("Silver Gym");
		gymNames.add("Body Fitness");
		
		
		List<String> timings =  new ArrayList<>();
		timings.add("Morning");
		timings.add("AfterNoon");
		timings.add("Evening");
		timings.add("night");
		
		model.addAttribute("gymNames",gymNames);
		model.addAttribute("timings",timings);
		model.addAttribute("customer",new Customer());
		
		return "AddCustomerPage";
	}
	
	@RequestMapping(value="processAddCustomerForm" , method=RequestMethod.POST)
	public String processAddCustomerForm(@ModelAttribute("customer") @Valid Customer customer, BindingResult result, Model model)
	{
		if (result.hasErrors())
		{
			List<String> gymNames = new ArrayList<>();
			
			
			gymNames.add("Golds Gym");
			gymNames.add("Talwalkars");
			gymNames.add("Silver Gym");
			gymNames.add("Body Fitness");
			
			
			List<String> timings =  new ArrayList<>();
			timings.add("Morning");
			timings.add("AfterNoon");
			timings.add("Evening");
			timings.add("night");
			
			model.addAttribute("gymNames",gymNames);
			model.addAttribute("timings",timings);
			model.addAttribute("customer",customer);
			
			return "AddCustomerPage";
		}
		int customerId = -1;
		try 
		{
			customerId =  bookingService.addCustomer(customer);
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			model.addAttribute("errMsg", "Something Went Wrong While Adding Customer Details");
			return "ErrorPage";
		}
		model.addAttribute("sMsg","Customer Adde Successfully With Id"+customerId);
		return "SuccessPage";
		
	}
	
	@RequestMapping("viewCustomer")
	public String getViewCustomerPage()
	{
		return "view";
	}
	
	@RequestMapping(value ="processViewCustomerDetailsForm", method=RequestMethod.POST)
	public String processViewCustomerDetailsForm(@RequestParam("customerId") int id , Model model)
	{
		Customer customer = null;
		
		try 
		{
			customer = bookingService.getCustomer(id);
		} 
		catch (Exception e) 
		{
			model.addAttribute("errMsg", "Something Went Wrong While Viewing");
			return "ErrorPage";
		}
		model.addAttribute("customer",customer);
		return "view";
		
	}
	

}
