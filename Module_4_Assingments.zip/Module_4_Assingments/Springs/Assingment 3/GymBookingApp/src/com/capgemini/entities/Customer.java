package com.capgemini.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Customers")
public class Customer 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mygen")
	@SequenceGenerator(name="mygen",sequenceName="customeridseq",initialValue=1000)
	private int id;
	
	@NotEmpty(message="Name Cannot Be Null")
	private String name;
	
	@Min(value=18, message="Age Cannot Be Less Than 18")
	@Max(value=50, message="Age Cannot Be Greater Than 50 ")
	private int age;
	
	@NotEmpty(message="Gym Name Cannot Be Empty")
	private String gymName;
	
	@NotEmpty(message="Atleaast 1 Time Should Be Selected")
	private String timings;
	public Customer(int id, String name, int age, String gymName, String timings) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.gymName = gymName;
		this.timings = timings;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGymName() {
		return gymName;
	}
	public void setGymName(String gymName) {
		this.gymName = gymName;
	}
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", age=" + age
				+ ", gymName=" + gymName + ", timings=" + timings + "]";
	}
	public Customer(String name, int age, String gymName, String timings) {
		super();
		this.name = name;
		this.age = age;
		this.gymName = gymName;
		this.timings = timings;
	}
	
	
	
	
	
	
}
