create sequence customeridseq start with 1000

select * from CustomerDetails;