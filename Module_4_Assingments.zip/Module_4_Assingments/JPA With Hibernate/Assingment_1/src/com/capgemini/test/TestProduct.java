package com.capgemini.test;

import static org.junit.Assert.*;

import com.capgemini.entities.Product;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductServiceImpl;

public class TestProduct {

	IProductService service;
	public TestProduct() {
	service= new ProductServiceImpl();
	}
	
	public static void setUpBeforeClass() throws Exception {
	}

	
	public static void tearDownAfterClass() throws Exception {
	}


	public void setUp() throws Exception {
	}

	
	public void tearDown() throws Exception {
	}

	
	public void test() {
		
		Product product1=new Product("Perfume",10,2500);
		//service.addProduct(product1);
		assertEquals(3,service.addProduct(product1) );
		
	}

}
