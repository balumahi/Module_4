package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.capgemini.dao.IProductDao;
import com.capgemini.dao.ProductDAOImpl;
import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

@Component("productService")
public class ProductServiceImpl implements IProductService{

	@Autowired
	 IProductDao productDao;

	
	public ProductServiceImpl() {
		//super();
		
		//productDao = new ProductDAOImpl();
	}
	
	

	public IProductDao getProductDao() {
		return productDao;
	}



	public void setProductDao(IProductDao productDao) {
		this.productDao = productDao;
	}



	@Override
	public String toString() {
		return "ProductServiceImpl [productDao=" + productDao + "]";
	}



	@Override
	public int addProduct(Product product) throws ProductException {
		
		return productDao.addProduct(product);
	}

	@Override
	public void updateProduct(Product product) throws ProductException {
		
		productDao.updateProduct(product);
	}

	@Override
	public Product getProduct(int id) throws ProductException {
		
		return productDao.getProduct(id);
	}

	@Override
	public void removeProduct(int id) throws ProductException {
		
		productDao.removeProduct(id);
		
	}


	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		return productDao.getAllProducts();
	}


	@Override
	public Product getProductByName(String name) throws ProductException 
	{
		
		return productDao.getProductByName(name);
	}


	@Override
	public List<Product> getProductByRange(float min, float max)
			throws ProductException 
	{
		
		return productDao.getProductByRange(min, max);
	}



}
